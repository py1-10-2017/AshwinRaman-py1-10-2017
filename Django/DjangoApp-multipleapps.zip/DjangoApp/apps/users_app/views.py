from __future__ import unicode_literals

from django.shortcuts import render, HttpResponse, redirect

def register(request):
    return HttpResponse("Placeholder for users to create a new user record")

def login(request):
    return HttpResponse("Placeholder for users to login")

def users(request):
    return HttpResponse("Placeholder to later display the list of users")
